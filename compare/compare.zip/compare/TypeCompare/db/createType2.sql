CREATE TYPE test AS (
	Id int,
	firstname varchar,
	lastname varchar,
	email varchar
);

CREATE TYPE test2 AS (
	Id int,
	name varchar,
	email2 varchar
);

CREATE TYPE test3 AS (
	Id int,
	name varchar
);

CREATE TYPE test5 AS (
	Id int,
	firstname varchar,
	email varchar
);

CREATE TYPE test1 AS (
	Id int,
	name varchar,
	email2 varchar
);