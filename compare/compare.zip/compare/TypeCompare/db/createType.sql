
CREATE TYPE test AS (
	Id int,
	firstname varchar,
	lastname varchar,
	email varchar
);

CREATE TYPE test2 AS (
	Id int,
	email2 varchar
);

CREATE TYPE test3 AS (
	Id int,
	name varchar,
	email varchar
);

CREATE TYPE test4 AS (
	Id int,
	name varchar,
	email varchar
);

CREATE TYPE test5 AS (
	Id int,
	firstname varchar,
	email varchar(50)
);
