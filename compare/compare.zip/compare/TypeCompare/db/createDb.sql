DROP DATABASE practice;

CREATE DATABASE practice;

DROP DATABASE practice2;

CREATE DATABASE practice2;