DROP TYPE IF EXISTS "subscriber"."ProviderType";

DROP TYPE IF EXISTS "subscriber"."SaveSubscriberRight";

DROP TYPE IF EXISTS "subscriber"."GstinType";

DROP TYPE IF EXISTS "subscriber"."SeriesSequenceNumberDetail";

DROP TYPE IF EXISTS "subscriber"."EntityType";

DROP TYPE IF EXISTS "subscriber"."GstinTurnoverType";


