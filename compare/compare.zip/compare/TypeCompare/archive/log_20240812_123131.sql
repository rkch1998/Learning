DROP TYPE IF EXISTS "app"."InsertCommandLogTypeBackup";


