ALTER TYPE "oregular"."ReconciliationSettingType" ALTER ATTRIBUTE "FilingExtendedDate" TYPE timestamp without time zone;


